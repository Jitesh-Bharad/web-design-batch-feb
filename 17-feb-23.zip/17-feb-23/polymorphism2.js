//Overriding (Runtime Polymorphism)
// When any method of base class is redefined in the derived class with exactly same signature(same name , same arguments) then it is called method overriding.
class A{
    constructor(a)
    {
        this.a=a;
    }
    show(){
        console.log('A');
    }
}
class B extends A{
    constructor(a,x)
    {
        super(a);
        this.x=x;
    }
    show()
    {
        console.log('B');
    }
}

let b=new B(10,20);
console.log(b.a);//10
console.log(b.x);//20
b.show();//B

let a=new A(100);
a.show();//A
