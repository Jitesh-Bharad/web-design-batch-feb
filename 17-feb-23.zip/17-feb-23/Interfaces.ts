
//Interface : Interface is a set of rules that must be followed by all the classes that implement the interface.
//Interface will be set of abstract methods.

//All the methods of interface are abstract.It means interface gives 100% abstraction.
//Multiple interfaces can be implemented by single class , where as multiple abstract classes can not be extended by a class.

//If any class implements any interface, then the class must either give implementation/body to all the abstract methods of interface  , or the class must be declared abstract.

//One interface can also extend another interface.

//We can not create object/instance of interface
interface Runnable{
    run();
}
interface Playable{
    play();
}
class Cricketer implements Playable,Runnable{
    play(){
        console.log("Playing cricket");
    }
    run() {
        console.log("Running for practice")
    }
}
class Musician implements Playable{
    play() {
        console.log("Playing Guitar");
    }
}

let c=new Cricketer();
c.play();//Playing Cricket
c.run();//Running for Practice

let m=new Musician();
m.play();//Playing Guitar