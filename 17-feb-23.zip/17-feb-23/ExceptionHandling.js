//Exceptions are the abnormal conditions that occur unexpectedly and can break the normal execution of the code.


//Exception Handling : It is the process of providing some alternate code at design time to be executed if some exception occurs at runtime.d

//Exception handling gives us a way to clearly separate the development code from the error handling code.

// try{
//     let x=12;
//     console.log('hello');
//     console.log(y);// throw new ReferenceError('y is not defined');
//     console.log(x);
//     console.log('world');    
// }catch(e){
//     console.log('Error Name : '+e.name);
//     console.log('Error Message : '+e.message);
// }




// let total_count=0;
// function vote(age)
// {
//     if(age>=18)
//     {
//         total_count++;
//         console.log("Successful voting done , total votes : "+total_count);
//     }
//     else{
//         throw new Error('Age not sufficient');
//     }
// }

// try{
// console.log("Welcome citizen ... ");
// vote(18);
// vote(19);
// vote(70);
// vote(12);
// vote(23);
// console.log("Thank you, you are done");
// }catch(e){
// console.log("NAME : "+e.name);
// console.log("Message : "+e.message);
// }

class VoteError extends Error{
    constructor(msg){
        super(msg);
        this.name='Vote Error';
    }    
}
class DummyError extends Error{

    constructor(msg)
    {
        super(msg);
        this.name="Dummy Error";   
    }
}
function dummy(input){
    let result=input*10;
    if(result<100){
        console.log("FINAL RESULT : "+result);
    }
    else{
        throw new DummyError('Value exceeding the limits');
    }
}

let total_count=0;
function vote(age)
{
    if(age>=18)
    {
        total_count++;
        console.log("Successful voting done , total votes : "+total_count);
    }
    else{
        throw new VoteError('Voting error , age not sufficient');
    }
}

try{
console.log("Welcome citizen ... ");
vote(18);
vote(19);
dummy(4);
vote(70);
dummy(2);
vote(12);
vote(23);
console.log("Thank you, you are done");
}catch(e){
    switch(e.name){        
        case "Vote Error":
            console.log('Sorry Kid');
            console.log(e.message);
            break;
        case "Dummy Error":
            console.log("Something wrong with your input ");
            console.log(e.message);
            break;
    }
}

