//Polymorphism : 
// If a single entity behaves differently in different situations, than it is polymorphic and the process is polymorphism.

//In OOP , a method with same name and multiple behaviours/implementations.

//Benefits : Same name can be reused , dynamic binding can be acheived.


// Overall 2 ways to acheive polymorphism : 
// 1. Overloading (Compile time polymorphism): Not supported in js.
//2. Overriding ( Runtime Polymorphism) : Supported in js


//method overloading : If a single class has multiple methods with same name but difference in arguments, than such methods are called overloaded methods and the process is called method overloading.
class A{
    constructor(name){
        this.name=name;
    }
    greet(msg)
    {
        console.log("MSG FOR "+this.name+':'+msg);
    }
    greet(){
        console.log('Hello '+this.name);
    }

}
let x=new A('John Paul');
x.greet();//Hello John Paul
x.greet("How are you");//Hello John Paul

//There will be no overloading , both the method calls will execute same method , which is defined later in the class.