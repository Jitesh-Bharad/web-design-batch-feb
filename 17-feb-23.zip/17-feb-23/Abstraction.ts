

//Abstraction : Hiding the implementation details of any function and providing only the interfaces to use it.

//Can be acheived using a. Abstract class  b. Interface


//Abstract

//It is a concept of OOP . Either a class can be abstract class or a method can be abstract method. An abstract entity will have no implementation , but only declaration.

//Abstract method 
//The method declared in a class but without any implementation details.

//Abstract class
//Any class that does not have full implementation. Abstract class can not be instantiated. Abstract classes are declared to be the placeholders for some common code for its children , The child class can give the full implementation to the abstract class by inheriting from it.

//Abstract class can be used for 0% - 100% abstraction.
//It means there is a possibility that all methods of abstract class are abstract, or no method is abstract or some are abstract and some are not.

abstract class Fruit{
    abstract getPrice();
}
class Mango extends Fruit
{
    getPrice()
    {
        console.log("140 per kg");
    }
}
class Apple extends Fruit{
    getPrice()
    {
        console.log("100 per kg");
    }
}
class Orange extends Fruit{
    getPrice()
    {
        console.log("90 per kg");
    }
}

let f= new Apple();
f.getPrice();