//collection of characters
//string is used to store text data.
// let x='hello world good morning';
let x='katappa killed';
let y='bahubali';
let z=x.concat(' ');
z=z.concat(y);
console.log(x);
console.log(y);
console.log(z);//katappa killed bahubali

console.log(z.charAt(9));//i
console.log(z.indexOf('p'));//4
let k=z.toUpperCase();
console.log(z);
console.log(k);//KATAPPA KILLED BAHUBALI
let l=k.toLowerCase();
console.log(k);//KATAPPA KILLED BAHUBALI
console.log(l);//katappa killed bahubali

let u=z.replace('a','u');
console.log(u);//

let v=z.replaceAll('a','u');
console.log(v);

let r=z.replaceAll('ki','pu');
console.log(r);//katappa pulled bahubali

let s='hello world';
console.log(s.length);//11

console.log(z.startsWith('ka'));//true
console.log(z.startsWith('ba'));//false
console.log(z.startsWith('katap'));//true

console.log(z.endsWith('li'));//true
console.log(z.endsWith('ba'));//false
console.log(z.endsWith('bahu'));//false
console.log(z.endsWith('bali'));//true

let s1='hello world';

console.log(s1.indexOf('o'));//4
console.log(s1.lastIndexOf('o'));//7

console.log(s1.includes('hello'));//true
console.log(s1.includes('hello '));//true
console.log(s1.includes('hello world'));//true
console.log(s1.includes('world'));//true
console.log(s1.includes('good world'));//false

let result=z.slice(4,10);//z='katappa killed bahubali'
console.log(result);//ppa ki
console.log(z.slice(5));//pa killed bahubali

let r1=z.substring(6,12);
console.log(r1);//a kill
console.log(z.substring(6));//a killed bahubali

let arr=z.split(' ')
console.log(arr);
arr.reverse();
console.log(arr);
let str1=arr.join(' ');
console.log(str1);

let  rev='';
for(let i=z.length-1;i>=0;i--)
{
    rev+=z[i];    
}
console.log(rev);


