
// let x=[12,90,19,99,2,8,9,16,20,17];
// let y=x.slice(2,8);
// console.log(x);
// console.log(y);

//let x=[12,90,19,99,2,8,9,16,20,17];
// let y=x.splice(2,3);//remove 3 elements
//                 //starting from index 2
// console.log(x);[12,90,8,9,16,20,17]
// console.log(y);//[19,99,2]

// let y=x.splice(2,0,10,20,30);
// console.log(x);
// console.log(y);


// let x=[12,90,19,99,2,8,9,16,20,17];
// x.splice(3,1,100);
// console.log(x);


// let x=[12,90,19,99,2,8,9,16,20,17];
// console.log(x.includes(100));
// console.log(x.includes(20));

// console.log(x.indexOf(19));//2
// console.log(x.indexOf(100));//-1



// let x=[12,9,10,100];
// let y=[200,78,99,6];
// let z=x.concat(y);
// console.log(z);
// console.log(x);
// console.log(y);


// WAP to find common elements of 2 array and print them.
// let x=[1,9,10,100,23,45];
// let y=[11,90,23,46,45,1];
// for(let i=0;i<x.length;i++)
// {
//     if(!(y.includes(x[i])))
//     {
//         console.log(x[i]);
//     }
// }

// WAP to find un-common elements of 2 array and print them.
// let x=[1,9,10,100,23,45];
// let y=[11,90,23,46,45,1];
// let z=x.concat(y);
// for(let i=0;i<z.length;i++)
// {
//     if( !((x.includes(z[i]) && (y.includes(z[i])))))
//     {
//         console.log(z[i]);
//     }
// }

// function filterMarks(input)
// {
//   return  (input>90?true:false);
// }
// let x=[12,90,100,78,67,78,90,99,94];
// let y=x.filter(filterMarks);
// console.log(y);


//let x=[100,299,90,89,88,46,44,42,9,3];
//WAP to filter this array such that the multiples of 4 are stored in new array y.
//WAP to filter prime numbers from an array.


//Break Keyword in loop
// for(let i=0;i<10;i++)
// {
//     console.log(i);
//     if(i==6)
//     {
//         break;
//     }
// }



//continue keyword in loop
//skips to the next iteration 

// for(let i=0;i<10;i++)
// {
//     if(i==6)
//     {
//         continue;
//     }
//     console.log(i);
// }




//Prime number

// function isPrime(num)
// {
//     if(num<2)
//     {
//         return false;
//     }
//     for(let i=2;i<(num-1);i++)
//     {
//         if(num%i==0)
//         {
//             return false;
//         }
//     }
//     return true;
// }
// let y=[1,90,22,489,87,88,65,64,100,13,12,11,17];
// let z=y.filter(isPrime);
// console.log(z);




//map : to apply a common operation on all the elements
// //and return a new array.
// function sqr(num)
// {
//     return num*num;
// }
// let x=[1,9,5,4,8,6];
// let y=x.map(sqr);
// console.log(y);



//Given an array , find another array which is formed by
//incrementing all the elemens of given array by 4.





// //sort method of array
// function sortCriteria(a,b)
// {
//     return b-a;
// }
// let arr=[12,10,19,2,3,89,34,45];
// let result=arr.sort(sortCriteria);
// console.log(result);


function sortCriteria(obj1,obj2)
{
    return obj2.marks-obj1.marks;
}

let stdArr=[{name:'ramesh',rollno:10,marks:80},{name:'suresh',rollno:2,marks:89},{name:'mahesh',rollno:3,marks:70}]

let res=stdArr.sort(sortCriteria);
console.log(res);



