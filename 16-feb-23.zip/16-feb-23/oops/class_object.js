//constructor is a method of a class that is executed implicitly at the time of object creation. It is used to initiaze the attributes of the class.

//State : Collection of all the properties of an object along with their current values 

//Method : Method of a class is the function which has access to the state of the class.
//Method can also update the state of the class.

// class Student{
//     constructor(nm,rl,m)
//     {
//         this.name=nm;
//         this.rollno=rl;
//         this.marks=m;
//     }
//     show()
//     {
//         console.log("Name : "+this.name);
//         console.log("Roll No : "+this.rollno);
//         console.log("Marks : "+this.marks);
//     }
// }

// //Creating object 
// let s=new Student('ramesh',1,99);
// let s1=new Student('suresh',2,89);

// s.show();
// s1.show();
// s.marks=92;
// s.show();

//Create an employee class with properties name :string, empid:number , salary : number . and 
//create a method to display these details.
//After creating the class , generate 2 instances of the class with different values //
//and call display method on both the instances. 







//Types of members in class : 1. instance 2. static

//Instance variables/methods are the part of object memory and they can be accessed on only objects.

// class A{
//     constructor(a,b)
//     {
//         this.a=a;
//         this.b=b;
//     }
// }
// let x=new A(1,2);
// let y=new A(3,5);
// console.log(x.a);//1
// console.log(x.b);//2
// console.log(y.a);//3
// console.log(y.b);//5
// x.a=90;
// console.log(x.a);//90
// console.log(x.b);//2
// console.log(y.a);//3
// console.log(y.b);//5


//Static variables : Those variables declared with static keyword. They do not memory in object instead they are class level. Objects can not access static variables, they have to be access via class name.

//static methods : Those methods which are declared using static keyword. They can only access static variables of the class. They can not access instance members of the class.
//Static methods can be used to add some utility functionality of the class
//which is not needed to access the state of class.
///Static methods can not be called on object.They can be called on class.
class A{
    static a=5;
    constructor(b)
    {
        this.b=b;
    }

    show()
    {
        console.log(this.#b);
        console.log(A.a);
    }

    static sum(num1,num2)
    {
        return num1+num2;
    }
}


let x=new A(1);
let y=new A(2);

x.show();
// console.log(A.a);//5
// console.log(x.b);//1
// console.log(y.b);//2
// A.a=10;
// console.log(A.a);

A.sum(1,2);

