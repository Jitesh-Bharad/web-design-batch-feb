//Inheritance is the property of any class to extend the features/capabilities of any other existing class.
//Benefit : Code Reusability , so that the development time reduces.
//Where : only in the cases where is-a relationship is satisfied.
class A {
    a;
    b;
    c;
    #d;
    constructor(a,b,c)
    {
        this.a=a;
        this.b=b;
        this.c=c;
    }
}
class B extends A{
    e;
    constructor(x,y,z,k)
    {
        super(x,y,z);//to call the parent class constructor
        this.e=k;
    }
    show()
    {
        console.log('a: '+this.a);
        console.log('b: '+this.b);
        console.log('c: '+this.c);
        console.log('e: '+this.e);        
    }
}
let b1=new B(10,20,30,40);
b1.show();