// Object : Any real world entity that has some properties 
// and behaviour , and existence in memory/space

// Class  : Collection of similar type of objects . Class can be
// the template/blueprint for objects


// Class Definition contains : a. Properties/Attributes/data members 
//                             b. behaviour/methods


// The generated object of the class will have : 

//                     a. properties 
//                     b. behaviour
//                     c. identity/memory address

// ANy number of objects can be created from a single class

// All the objects of same class will have same set of properties 
// and behaviour however the value of properties can differ















