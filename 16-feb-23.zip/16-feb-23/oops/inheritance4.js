//Types of inheritance : 

//1. Single Inheritance 
//2. Multilevel Inheritance 
//3. Hierarchical Inheritance 
//4. Multiple Inheritance
//5. Hybrid 

//Hybrid