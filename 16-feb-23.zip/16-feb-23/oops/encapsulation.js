//Encapsulation : Binding of data along with the methods that are dependent on that data together into a single unit(class) is known as encapsulation. It is useful to logically bind the owner functions of data along with them.

//Encapsulation can allow a developer to provide access levels to the data and methods of the class with the help of access specifiers.
// class A{
//     #b;    
//     constructor()
//     {
//         this.a=12;
//         this.#b=20;
//     }
//     show(){
//     console.log("a : "+this.a);
//     console.log('b : '+this.#b);
//     }
// }
// let a1=new A();
// a1.show();
// a1.a=100;
// a1.#b=200;//error as #b is private
// a1.show();




//Setters and getters can be used to have access to private members outside the class but not directly , instead indirectly.
class A{
    #b;   //private member of class 
    constructor()
    {
        this.a=12;
        this.#b=20;
    }

    set b(value)
    {
        console.log('setter b called');
        this.#b=value;
    }
    
    get b()
    {
        console.log('getter b called');
        return this.#b;
    }

    show(){
    console.log("a : "+this.a);
    console.log('b : '+this.#b);
    }
}
let a1=new A();
a1.show();
a1.a=100;
console.log('hello');
a1.b=200;//this will call set b
a1.show();
console.log('world');
console.log(a1.b);//200 //this will call get b