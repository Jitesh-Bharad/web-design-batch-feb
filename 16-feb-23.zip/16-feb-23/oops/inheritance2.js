//Types of inheritance : 

//1. Single Inheritance 
//2. Multilevel Inheritance 
//3. Hierarchical Inheritance 
//4. Multiple Inheritance
//5. Hybrid 

// Example of hierarchical inheritance
class A{
    a;
    constructor(a)
    {
        this.a=a;
    }
}
class B extends A{
    b;
    constructor(a,b){
        super(a);
        this.b=b;
    }
    show()
    {
        console.log(this.a);
        console.log(this.b);
    }
}
class C extends A{
    c;
    constructor(a,c){
        super(a);
        this.c=c;
    }
    show()
    {
        console.log(this.a);
        console.log(this.c);
    }
}
let b1=new B(1,2);
let c1=new C(4,8);

b1.show();
c1.show();
