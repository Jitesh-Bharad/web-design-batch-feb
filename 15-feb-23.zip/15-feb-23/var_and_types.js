
var x=21;
console.log(x);//21
console.log(typeof(x));//number
x='hello';
console.log(x);//hello
console.log(typeof(x));//string
x=true;
console.log(x);//true
console.log(typeof(x));//boolean
var y;
console.log(y);//undefined
console.log(typeof(y));//undefined
var z=null;
console.log(z);
console.log(typeof(z));

var std={name:'john',rollno:1,marks:99.123};//object literal
console.log(typeof(std));//object
console.log(std);


var k=[12,10,100,90,50];//array of 5 elements
console.log(typeof(k));//object

function test(){
    console.log('hello world');
}

console.log(typeof(test));//function


// console.log(o);
// o=12;//It will be hoisted
// console.log(o);

// o=o+1;//Reference Error
// console.log(o);

