// for(let j=0;j<5;j++)
// {
//     var x='';
//     for(let i=0;i<7;i++)
//     {
//         x+='*';
//     }
//     console.log(x);    
// }

// for(let j=1;j<=7;j++)
// {
//     var x='';
//     for(let i=1;i<5;i++)
//     {
//         x+=j;
//     }
//     console.log(x);    
// }


// for(let j=1;j<=4;j++)
// {
//     var x='';
//     for(let i=1;i<=j;i++)
//     {
//         x+=j;
//     }
//     console.log(x);
// }


// for(let j=4;j>=1;j--)
// {
//     var x='';
//     for(let i=1;i<=j;i++)
//     {
//         x+=j;
//     }
//     console.log(x);
// }



for(let j=1;j<=4;j++)
{
    var x='';
    for(let i=1;i<=j;i++)
    {
        x+=j;
    }
    console.log(x);
}
for(let j=3;j>=1;j--)
{
    var x='';
    for(let i=1;i<=j;i++)
    {
        x+=j;
    }
    console.log(x);
}







