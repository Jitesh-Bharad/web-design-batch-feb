//console.log('good morning world');

// document.write("World");
// document.write("<h2>Title Here</h2>");

// alert('Hello , I am again here, now in dialogue')

document.querySelector('#p2').innerHTML='I am here again!...';