// let x=12;
// if(x>19)
// {
//     console.log('hello');
// }
// console.log('good');
// console.log('world');


//if ...else 
// let x=12;
// if(x<20)
// {
//     console.log('hello');
// }
// else{
//     console.log('bye');
// }


// let age=10;

// if(age>=18)
// {
//     console.log("You can vote");
// }
// else{
//     console.log("You can not vote");
// }

// let x=10;
// if(12)
// {
//     console.log("good");
// }else{
//     console.log("bye");
// }
// 90-100 : A
//80-90 : B
//70-80  : C
//60-70 : D
//0-60 : FAIL 
// let marks=-8;

// if(marks>90 && marks<=100)
// {
//     console.log("A");
// }
// else if(marks>80 && marks<=90)
// {
//     console.log("B");
// }
// else if(marks>70 && marks<=80)
// {
//     console.log("C");
// }
// else if(marks>60 && marks<=70)
// {
//     console.log("D");
// }
// else if(marks>=0 && marks<=60){
//     console.log("FAIL")
// }
// else{
//     console.log("INVALID MARKS");
// }


//switch - case
let dayNo=7;
switch(dayNo)
{
    case 4 : 
        console.log("Thursday");
        break;
    case 5:
        console.log("Friday");
        break;
    case 1:
        console.log("Monday"); 
        break;
    default:
        console.log("Invalid"); 
        break;
    case 6 : 
        console.log("Saturday");    
        break;
    case 2 : 
        console.log("Tuesday");
        break;
    case 3:
        console.log("Wednesday");
        break;
    case 7:
        console.log("Sunday");
}
