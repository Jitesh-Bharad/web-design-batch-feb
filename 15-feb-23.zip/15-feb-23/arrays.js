// collection of similar elements stored under same name

// let x=[1,2,4,50];

// let x=[1,2,4,50,90,100];
//length of array
// console.log(x.length);//6

//getting first element 
// console.log(x[0]);//1

//getting last element
// let len=x.length;
// console.log(x[len-1]);//100

// WAP to declare and initialize an array with some constant values and print the sum of first and last Element.

// let y=[1,39,19,100,1948,89,3804,1083,194,234,90];
// let first=y[0];
// let last=y[y.length-1];
// let sum=first+last;
// console.log(sum);


// let y=[1,39,19,100,1948,89,3804,1083,194,234,90];
// //iterate over array elements
// for(let i=0;i<y.length;i++)
// {
//     console.log(y[i]);
// }


//WAP to find sum of all the elements of an array

// let y=[12,90,9,8,284,119,290,9,4820,90];

// let sum=0;
// for(let i=0;i<y.length;i++)
// {
//     sum=sum+y[i];
// }
// console.log(sum);

// let y=['hello','world','how','are','you'];
// y.push('i');
// y.push('am');
// y.push('fine');
// console.log(y);// ['hello', 'world','how','are','you','i','am','fine']
// y.pop();
// console.log(y);//['hello','world' ,'how','are','you','i','am']

// let s=y.toString();
// s=s.replaceAll(',',' ')
// console.log(s);

// let s1=y.join(' ');
// console.log(s1);


let y=[12,90,100,23,89,7,4,12];
console.log(y);
y.reverse();
console.log(y);

