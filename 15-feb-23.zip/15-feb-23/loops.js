// let i=1;//initialization
// while(i<5)//condition
// {
//     console.log(i);
//     i++;//increment/decrement
// }

// for(let i=1;i<5;i++)
// {
//     console.log(i);    
// }
// for(let i=19;i>=1;i=i-2)
// {
//     console.log(i);
// }


// for(i=100;i>=1;i--)
// {
//     if(i%4==0)
//     {
//         console.log(i);
//     }
// }


// while(false)
// {
//     console.log('hello')
// }

// do
// {
//     console.log('hello')
// }while(false);

// let i=1
// while(i<5)
// {
//     console.log(i);
//     i++;
// }

// let i=1;
// do{
//     console.log(i);
//     i++;
// }while(i<5);




// WAP to print even numbers between 22 and 55 
// WAP to calculate sum of all numbers from 1 to 10 using loop
// WAP to find the sum of even numbers that exist between 1 and 20
// WAP to declare and initialize a variable with a integer number
// and print its table in following format.WAP

// 4 
// 4X1 = 4
// 4x2=  8
// . 
// . 
// 4x10=40

let num=4;
for(let i=1;i<=10;i++)
{
    console.log(num+'x'+i+'='+num*i);
}
    


