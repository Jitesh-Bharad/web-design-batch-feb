// // = is assignment whereas == is comparison
// let x=13;
// let y=23;
// if(x=y)//note : assignment operator here will assign 23 to x and
//         //23 is true
// {
//     console.log('yes');
// }
// console.log(x);
// console.log(y);

// //output yes 
//         //23
//         //23



// // == is comparison
// let x=13;
// let y=23;
// if(x==y)//note : comparison operator here will compare x and y  and
//         //will return false
// {
//     console.log('yes');
// }
// console.log(x);//13
// console.log(y);//23


//Relational Operators
// console.log(12<5);//false
// console.log(12>5);//true
// console.log(12==12);//true
// console.log(12==5);//false
// console.log(12!=5);//true
// console.log(12!=12);//false


//Logical Operators :

// && : Logical AND (Binary)
//return true if both inputs are true else return false
// let x= (true && true);
// console.log(x);//true
// x=(true && false);
// console.log(x);//false
// x=(false && true);
// console.log(x);//false
// x=(false && false);
// console.log(x);


// || Logical OR (Binary)
// let y=true || true;
// console.log(y);//true
// y=false || true;
// console.log(y);//true
// y=false || false;
// console.log(y);//false
// y=true||false;
// console.log(y);//true


// !  Logical Not (Unary)
// let z = !(true);
// console.log(z);//false
// z=!(false);
// console.log(z);//true

//Example
// let a=12;
// let b=23;
// let z=!(a==b);
// console.log(z);//true

// let k=(a!=b);
// console.log(k);//true


//Assignment Operators
// let k=12;
// let m=90;
// let result=k=m;
// console.log(k);//90
// console.log(m);//90
// console.log(result);//90
// let result2=(k==m);
// console.log(k);//90
// console.log(m);//90
// console.log(result2);//true


// let k=23;
// k+=10;//equivalent to k=k+10
// console.log(k);//33


//Ternary Operator

//   target_var = (condition) ? result1 : result2
  //if condition is true result1 will be assigned to target_var
  //if condition is false result2 will be assigned to target_var

  //example
  
  let a=12;
  let b=20;
  let z=(a>b)?100:200;
  console.log(z);