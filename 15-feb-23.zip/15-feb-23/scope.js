//var : Variables declared with var keyword will have only 2 types of scopes
//function level and global level.
// var mno=12;
// function test()
// {
//     var mno=20;
//     {
//          var mno=90;
//          console.log(mno);//90        
//     }
//     console.log(mno);//90
// }
// test();
// console.log(mno);//12




// let mno=12;
// function test()
// {
//     let mno=20;
//     {
//          let mno=90;
//          console.log(mno);//90
//     }
//     console.log(mno);//20
// }
// test();
// console.log(mno);//12





//const keyword can be used to declare constants, it means their value
//once assigned , can not be changed later. The scope rules on const will be same as let

const x=12;
x=90;//error as x is constant
console.log(x);



